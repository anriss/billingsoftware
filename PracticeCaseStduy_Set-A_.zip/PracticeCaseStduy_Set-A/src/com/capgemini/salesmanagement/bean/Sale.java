package com.capgemini.salesmanagement.bean;

import java.time.LocalDate;
import java.util.Date;

public class Sale {
	private int saleId;
	private int prodCode;
	private String productName;
	private String category;
	private Date saleDate;
	private int quantity;
	private float lineTotal;
	private String productDescription;
	private float price;
	public Sale() {}

	public Sale(int prodCode, int quantity, String category, String productName, float price, float lineTotal) {
		super();
		this.prodCode = prodCode;
		this.productName = productName;
		this.category = category;
		this.saleDate = saleDate;
		this.quantity = quantity;
		this.lineTotal = lineTotal;
	}
	

	public Sale(int saleId, int prodCode, String productName, String category, Date saleDate, int quantity,float price,
			float lineTotal) {
		super();
		this.saleId = saleId;
		this.prodCode = prodCode;
		this.productName = productName;
		this.category = category;
		this.saleDate = saleDate;
		this.quantity = quantity;
		this.lineTotal = lineTotal;
		this.price=price;
	}

	public int getSaleId() {
		return saleId;
	}

	public void setSaleId(int saleId) {
		this.saleId = saleId;
	}

	public int getProdCode() {
		return prodCode;
	}

	public void setProdCode(int prodCode) {
		this.prodCode = prodCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Date getSaleDate() {
		return saleDate;
	}

	public void setSaleDate(Date SaleDate) {
		this.saleDate = SaleDate;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public float getLineTotal() {
		return lineTotal;
	}

	public void setLineTotal(float lineTotal) {
		this.lineTotal = lineTotal;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String toString()
	{
		return "Sale Id: "+ saleId+" Product Name: "+productName+" Category: "+category+" Sale date: "+saleDate+" Quantity: "+ quantity+" Total bill amount: "+lineTotal;
	}

}
