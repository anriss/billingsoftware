package com.capgemini.salesmanagement.util;

import java.text.DateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.capgemini.salesmanagement.bean.Sale;

public class CollectionUtil {
public static HashMap<Integer, Sale>sales=new HashMap<Integer, Sale>();
public static int SALE_ID= (int) (Math.random()*1000);
private static Date saleDate= new Date();
public static HashMap<Integer, Sale> getSales() {
	return sales;
}
public static void setSales(HashMap<Integer, Sale> sales) {
	CollectionUtil.sales = sales;
}
public static int getSALE_ID() {
	return SALE_ID;
}
public static Date getSaleDate() {
	return saleDate;
}
/*public static void setSaleDate(Date saleDate) {
	CollectionUtil.saleDate = saleDate;
}*/



}
