package com.capgemini.salesmanagement.service;

import java.util.HashMap;
import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductCodeException;
import com.capgemini.salesmanagement.exceptions.InvalidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidProductPriceException;
import com.capgemini.salesmanagement.exceptions.InvalidProductQuantityException;

public interface ISaleService {
public HashMap<Integer, Sale>insertSalesDetails(Sale sale);
public boolean validateProductCode(int prodCode) throws InvalidProductCodeException;
boolean validateQuantitiy(int quantity) throws InvalidProductQuantityException;
public boolean validateProductCat(String prodCat) throws InvalidProductCategoryException;
public boolean validateProductName(String productName) throws InvalidProductNameException;
public boolean validateProductPrice(float price) throws InvalidProductPriceException;
public float lineTotal(float price, int quantity,float lineTotal) throws InvalidProductPriceException,InvalidProductQuantityException;
}
