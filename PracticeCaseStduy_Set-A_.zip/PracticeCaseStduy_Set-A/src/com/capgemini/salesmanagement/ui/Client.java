package com.capgemini.salesmanagement.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductCodeException;
import com.capgemini.salesmanagement.exceptions.InvalidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidProductPriceException;
import com.capgemini.salesmanagement.exceptions.InvalidProductQuantityException;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class Client {
	public static void main(String[] args) throws InvalidProductCodeException, InvalidProductQuantityException,InvalidProductPriceException,InvalidProductCategoryException{
		int prodCode=0;
		String productName=" ";
		String category=" ";
		LocalDate saleDate=null;
		int quantity=0;
		float price=0.0f;
		float lineTotal=0.0f;
		Scanner sc = new Scanner(System.in);
		ISaleService service=new SaleService();
		try {
			System.out.println("Enter the product code: ");
			prodCode= sc.nextInt();
			service.validateProductCode(prodCode);
			System.out.println("Enter the quantity: ");
			quantity=sc.nextInt();
			service.validateQuantitiy(quantity);
			System.out.println("Enter the product category: ");	
			category=sc.next();
			service.validateProductCat(category);
			System.out.println("Enter the product name: ");
			productName=sc.next();
			service.validateProductName(productName);
			System.out.println("Enter the price: ");
			price = sc.nextFloat();
			service.validateProductPrice(price);
			lineTotal=quantity*price; 
		}
		catch(InvalidProductCategoryException|InvalidProductNameException|InvalidProductPriceException|InvalidProductQuantityException|InvalidProductCodeException e)
		{
			e.printStackTrace();
		}
		Sale sale = new Sale(prodCode,quantity,category,productName,price,lineTotal);
		System.out.println(service.insertSalesDetails(sale));
	}

}
